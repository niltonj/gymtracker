export default function Workouts(){ return <div>Workouts (em breve)</div>; }
